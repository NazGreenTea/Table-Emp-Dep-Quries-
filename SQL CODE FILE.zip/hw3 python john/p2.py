#import necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import trimesh
 
# Function to generate a user anchor constraint
def arap_deformation(mesh, indices_file, positions_file):
   # load the mesh
   mesh = trimesh.load(mesh)
 
   # load indices and positions from the files
   indices = np.loadtxt(indices_file, dtype=int)
   positions = np.loadtxt(positions_file)
 
   # set the user anchor constraints
   for i in range(len(indices)):
       mesh.vertices[indices[i]] = positions[i]
 
   # compute the cotangent weights of the mesh
   cot_weights = mesh.cot_weight_matrix()
 
   # initialise the rotation matrices to the identity matrix
   R = np.eye(3)
 
   # perform the global solve to compute the optimal vertex positions
   x = np.linalg.solve(cot_weights, R)
 
   # iteratively update the rotation matrices
   while True:
       # compute the rotation matrices from the local step
       R = mesh.local_rotations(x)
 
       # perform the global solve to compute the optimal vertex positions
       x = np.linalg.solve(cot_weights, R)
 
       # check if the deformation result is satisfactory
       if np.sum((x - mesh.vertices) ** 2) < 1e-5:
           break
 
   # set the new vertex positions
   mesh.vertices = x
 
   # return the mesh with the user anchor constraints
   return mesh
 
 
# Example usage:
mesh = arap_deformation("dino.off", "indices-dino.off.txt", "positions-dino.off.txt")
 
# Plot the mesh
plt.triplot(mesh.vertices[:,0], mesh.vertices[:,1], mesh.faces)
plt.show()
