#import necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import trimesh
 
# Function to generate a user anchor constraint
def alm_solver(K, d_user):
   # Initialise the Lagrange multipliers and penalty parameter
   l = np.zeros(len(d_user))
   penalty_param = 1
   d = np.zeros(K.shape[0])
  
   # Set the maximum iteration number
   max_iter = 1000
  
   # Run the ALM algorithm
   for i in range(max_iter):
       # Solve the unconstrained optimization problem
       d = np.linalg.solve(K + np.diag(penalty_param*l), penalty_param*d_user)
      
       # Calculate the penalty function
       penalty_func = np.sum((d-d_user)**2)
      
       # Update the Lagrange multipliers and penalty parameter
       l = l + 1/penalty_param*(d - d_user)
       penalty_param = penalty_param * 2
      
       # Check for convergence
       if penalty_func < 1e-5:
           print("ALM converged after {} iterations".format(i))
           break
 
   # Return the solution
   return d
 
# Example usage:
K = np.array([[1, 0], [0, 1]])
d_user = np.array([1, 1])
d = alm_solver(K, d_user)
 
# Print the solution
print("Optimal value of d:", d)
